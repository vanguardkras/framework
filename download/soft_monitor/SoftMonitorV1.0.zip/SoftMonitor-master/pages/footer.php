<div class="footer">
    <h3><?= FOOTER_1 ?></h3>
    <p><?= FOOTER_2 ?> &copy;SHAIAN</p>
</div>
</body>
</html>