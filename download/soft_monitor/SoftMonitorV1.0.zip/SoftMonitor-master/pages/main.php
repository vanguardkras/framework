<form name="launch" action="" method="post">
    <input type="submit" value="<?= RUN_BUTTON ?>" name="run">
    <input type="submit" value="<?= STOP_BUTTON ?>" name="stop">
</form>
<p>
    <?= MAIN_1 ?>
</p>
<p>
    <?= MAIN_2 ?>
</p>
<p>
    <?= MAIN_3 ?>
</p>